/*!
 * jQuery JavaScript Library v@VERSION
 * http://jquery.com/
 *
 * Copyright (c) 2009 John Resig
 * Dual licensed under the MIT and GPL licenses.
 * http://docs.jquery.com/License
 *
 * Date: 
 * Revision: 
 */
(function(){

